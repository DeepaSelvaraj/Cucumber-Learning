package stepDefenition;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class OpenOlx {
	
	WebDriver driver;
	
	@Given("^user is entering olx\\.com$")
	public void user_is_entering_olx_com() throws Throwable {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\dselva001c\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.olx.in");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		Thread.sleep(5000);
		System.out.println("Launched successfully");
	}

	@When("^user clicks the submit free ad button$")
	public void user_clicks_the_submit_free_ad_button() throws Throwable {
		
		WebElement btn = driver.findElement(By.xpath("//*[@id=\'postNewAdLink\']/span"));
		btn.click();
		System.out.println("clicked button successfully");
	}

	@When("^types the user basic details$")
	public void types_the_user_basic_details() throws Throwable {
	   WebElement Ad = driver.findElement(By.name("data[title]"));
	   Ad.sendKeys("Coffee Mug");
	   WebElement category = driver.findElement(By.xpath("//*[@id=\'targetrenderSelect1-0\']/dt/a"));
	  category.click();
	  Thread.sleep(3000);
	  WebElement item = driver.findElement(By.xpath("//*[@id=\'cat-1417\']/span[2]/strong"));
	  item.click();
	  WebElement price = driver.findElement(By.xpath("//*[@id=\'parameter-div-price\']/div[2]/div/div[1]/p/span/input"));
	  price.sendKeys("100");
	  WebElement AdDescription = driver.findElement(By.name("data[description]"));
	  AdDescription.sendKeys("Coffe Mug for sale");
	  WebElement Name = driver.findElement(By.name("data[person]"));
	  Name.sendKeys("Kiya");
	  WebElement phno = driver.findElement(By.name("data[phone]"));
	  phno.sendKeys("8529631479");
	  WebElement city = driver.findElement(By.name("data[city]"));
	  city.sendKeys("Chennai");
      Robot robot = new Robot();
      robot.keyPress(KeyEvent.VK_ENTER);
      robot.keyRelease(KeyEvent.VK_ENTER);
           
	  WebElement submit = driver.findElement(By.xpath("//*[@id=\'save\']"));
	  submit.click();
	  System.out.println("Done");
	   
	}

	@Then("^the user should be able to sumbit the free Ad$")
	public void the_user_should_be_able_to_sumbit_the_free_Ad() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		System.out.println("Mary");
	}



}
